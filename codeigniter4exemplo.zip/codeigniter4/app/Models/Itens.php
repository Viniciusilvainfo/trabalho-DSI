<?php

namespace App\Models;

use CodeIgniter\Model;

class Itens extends Model
{
    protected $table            = 'itens';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['nome', 'idade', 'descricao'];
}


// php spark make:model Itens