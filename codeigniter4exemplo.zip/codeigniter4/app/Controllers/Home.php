<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        return view('formulario');
    }

    public function registro() {
        $nome = $this->request->getVar('nome');
        $idade = $this->request->getVar('idade');
        $descricao = $this->request->getVar('descricao');

        $data['nome'] = $nome;
        $data['idade'] = $idade;
        $data['descricao'] = $descricao;

        $itensModel = new Itens();
        $itensModel->insert($data);

        return redirect()->to(base_url('/listar'));
    }

    public function listar() {
        $itensModel = new Itens();
        $todos_os_dados = $itensModel->findAll();

        $data['dados'] = $todos_os_dados;
        return view('result', ['data'=>$data['dados']]);
    }

    public function mostrarEditar($id) {
        $orders_model = new Itens();
        $result = $orders_model->find($id);
        $data['edicao'] = $result;

        return view('formEdicao', ['data'=>$data['edicao']]);
    }

    public function edicao() {
        $nome = $this->request->getVar('nome');
        $idade = $this->request->getVar('idade');
        $descricao = $this->request->getVar('descricao');
        $id = $this->request->getVar('id');

        $data['nome'] = $nome;
        $data['idade'] = $idade;
        $data['descricao'] = $descricao;

        $itensModel = new Itens();
        $itensModel->update($id, $data);
        return redirect()->to(base_url('/listar'));
        
    }
    public function deletar($id) {
        echo $id;
        $itensModel = new Itens();
        $itensModel->delete($id);

        return redirect()->to(base_url('/listar'));
    }
}
