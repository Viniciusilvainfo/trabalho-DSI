<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem</title>
    <style>
        table {
            margin:auto;
            text-align:center;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .a {
            display: block;
            width: 30px;
            margin:auto;
        }
    </style>
</head>
<body>
    <table border=1>
        <thead>
            <tr>
                <td>Nome</td>
                <td>Idade</td>
                <td>Descricao</td>
                <td>Editar</td>
                <td>Excluir</td>
            </tr>
        </thead>
        <tbody>
        <?php
            foreach($data as $item) {
                echo '<tr>';
                echo '<td>'.$item['nome'].'</td>';
                echo '<td>'.$item['idade'].'</td>';
                echo '<td>'.$item['descricao'].'</td>';
                ?>
                <td><a href=" <?php echo base_url('editar/'.$item['id']) ?> ">Editar</a></td>
                <td><a href=" <?php echo base_url('excluir/'.$item['id']) ?> ">Excluir</a></td>
            </tr>
            <?php
            }
        ?>
        </tbody>
    </table>
<a href="/" class="a">Voltar</a>
</body>
</html>