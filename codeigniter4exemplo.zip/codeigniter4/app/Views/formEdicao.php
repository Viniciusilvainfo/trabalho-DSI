<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="/editar"  method="post">
        <input name="id" id="id" type="hidden" value="<?php echo $data['id']; ?>">
        <label for="nome">Nome:</label>
        <input name="nome" id="nome" type="text" value="<?php echo $data['nome']; ?>">
        <label for="idade">Idade:</label>
        <input name="idade" id="idade" type="number" value="<?php echo $data['idade']; ?>">
        <label for="descricao">Descrição:</label>
        <input name="descricao" id="descricao" type="text" value="<?php echo $data['descricao']; ?>">
        <input type="submit" value="Editar">
    </form>
</body>
</html>