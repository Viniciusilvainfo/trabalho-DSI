<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videogame</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: purple;
        }
        
        form {
            color: white;
        }
        table {
            background-color: white;
        }
    </style>
    <script src="https://kit.fontawesome.com/254591610d.js" crossorigin="anonymous"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Videogames</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">Página Principal</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/fazerAluguel">Fazer aluguel</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarJogo">Adicionar jogo</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarUsuario">Adicionar usuário</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarCategoria">Adicionar categoria</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>

    <?php
    if(isset($_GET['erro'])) {
        echo '<h4 class="text-center">Não foi encontrado nada tente outra pesquisa </h4>';
    }

    ?>

    <div class="btn-group mx-auto d-flex w-50 text-center mt-5" role="group" aria-label="Basic outlined example">
        <button type="button" class="btn btn-outline-primary btn-light" id="btn1">Jogos</button>
        <button type="button" class="btn btn-outline-primary btn-light" id="btn2">Console</button>
        <button type="button" class="btn btn-outline-primary btn-light" id="btn3">Categoria</button>
    </div>
    <form method="get" action="/pesquisa" class="mb-5 mt-2 w-50 mx-auto" id="valor1">
        <div class="input-group">
            <input type="text" class="form-control" placeholder="Jogo" aria-label="jogo" aria-describedby="basic-addon1" name="jogo">
            <input class="d-none" name="campo" value="1">
            <button class="input-group-text" id="basic-addon1">Pesquisar</button>
        </div>
    </form>
    <form method="get" action="/pesquisa" class="mb-5 mt-2 w-50 mx-auto d-none" id="valor2">
        <div class="input-group">
            <select class="form-select" name="console">
                <?php foreach($consoles as $itens) { ?>
                    <option value="<?= $itens['sistema']  ?>"><?= $itens['sistema']  ?></option>
                <?php } ?>
            </select>
            <input class="d-none" name="campo" value="2">
            <button class="input-group-text" id="basic-addon1">Pesquisar</button>
        </div>
    </form>
    <form method="get" action="/pesquisa" class="mb-5 mt-2 w-50 mx-auto d-none" id="valor3">
        <div class="input-group">
            <select class="form-select" name="categoria">
                <?php foreach($categorias as $item) { ?>
                    <option value="<?= $item['id'] ?>"><?= $item['nome']  ?></option>
                <?php } ?>
            </select>
            <input class="d-none" name="campo" value="3">
            <button class="input-group-text" id="basic-addon1">Pesquisar</button>
        </div>
    </form>

    <table class="table table-hover mt-5 w-75 mx-auto">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Nome</th>
        <th scope="col">Preço por unidade</th>
        <th scope="col">Plataforma</th>
        <th scope="col">Quantidade</th>
        <th scope="col"></th>
        <th scope="col"></th>
        </tr>
    </thead>
    <tbody>
        <?php
        if(isset($cont) and $cont == 1) { ?>
            <tr>
            <th scope="row"><?=$dados['id']?></th> 
            <td><?=$dados['nome']?></td>
            <td><?=$dados['preco']?></td>
            <td><?=$dados['sistema']?></td>
            <td><?=$dados['quantidade']?></td>
            <td><a href="/mostraEdicao?jogo=<?=$dados['id']?>" class="fa-solid fa-pen-to-square"></a></td>
            <td><a href="/remover?jogo=<?=$dados['id']?>" class="fa-solid fa-trash text-danger"></a></td>
        </tr>
        <?php
        }else {
        foreach($dados as $chave => $dado) { ?>
        <tr>
            <th scope="row"><?=$dado['id']?></th> 
            <td><?=$dado['nome']?></td>
            <td><?=$dado['preco']?></td>
            <td><?=$dado['sistema']?></td>
            <td><?=$dado['quantidade']?></td>
            <td><a href="/mostraEdicao?jogo=<?=$dado['id']?>" class="fa-solid fa-pen-to-square"></a></td>
            <td><a href="/remover?jogo=<?=$dado['id']?>" class="fa-solid fa-trash text-danger"></a></td>
        </tr>
        <?php }} ?>
    </tbody>
    </table>

    <div class="btn-group mx-auto d-flex justify-content-center w-50 text-center mt-5" role="group" aria-label="Basic outlined">
        <form action="/pesquisa" method="get">
            <input class="d-none" name="campo" value="4">
        <button type="submit" class="btn btn-outline-primary btn-light" id="btn1">Jogo mais caro de todos</button>
        </form>
        <form action="/pesquisa" method="get">
            <input class="d-none" name="campo" value="5">
            <button type="submit" class="btn btn-outline-primary btn-light" id="btn2">Jogo de maior quantidade</button>
        </form>
    </div>
    <div class="btn-group mx-auto d-flex justify-content-center w-50 text-center" role="group" aria-label="Basic outlined">
    <form action="/relatorio" method="get">
            <input class="d-none" name="campo" value="5">
            <button type="submit" class="btn btn-outline-primary btn-light" id="btn2">Produtos por usuário</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
        var valor1 = document.getElementById('valor1');
        var valor2 = document.getElementById('valor2');
        var valor3 = document.getElementById('valor3');

        for(let c = 1; c < 4; c++) {
            let btn = document.getElementById('btn'+c);
            btn.addEventListener('click', ()=> {
                switch(c) {
                    case 1:
                        valor1.classList.remove('d-none');
                        valor2.classList.add('d-none');
                        valor3.classList.add('d-none');
                        break;
                    case 2:
                        valor2.classList.remove('d-none');
                        valor1.classList.add('d-none');
                        valor3.classList.add('d-none');
                        break;
                    case 3:
                        valor3.classList.remove('d-none');
                        valor2.classList.add('d-none');
                        valor1.classList.add('d-none');
                        break;
                }
            });
        }
    </script>
</body>
</html>