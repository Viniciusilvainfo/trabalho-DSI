<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videogame</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: purple;
        }
        
        form {
            color: white;
        }
        table {
            background-color: white;
        }
    </style>
    <script src="https://kit.fontawesome.com/254591610d.js" crossorigin="anonymous"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Videogames</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">Página Principal</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/fazerAluguel">Fazer aluguel</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarJogo">Adicionar jogo</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarUsuario">Adicionar usuário</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarCategoria">Adicionar categoria</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>

    <table class="table table-hover mt-5 w-75 mx-auto">
    <thead>
        <tr>
        <th scope="col">Usuario</th>
        <th scope="col">Compras</th>
        <th scope="col">Total</th>
        </tr>
        <?php 
            $valores = array();
        foreach($gastos as $chave =>$gasto) {
            $jogos = "";
            foreach ($gasto as $chaves => $item) {
                if($chaves != 'valor') {
                    $jogos = $jogos != "" ? $jogos .', ' . $item : $item;
                }else {
                    array_push($valores, $item);
        ?>
                <tr>
                    <td><?= $chave?></td>
                    <td><?= $jogos?></td>
                    <td>R$ <?= $item?></td>
                </tr>
        <?php
                }
            }
        } ?>

        </thead>
    <tbody>
    </tbody>
    </table>
        
        <?php foreach($gastos as $chave =>$gasto) {
            if ($gasto['valor'] == max($valores)) {
                echo '<h3 class="text-center">O usuário '.$chave.' foi o que mais gastou com R$'.max($valores).'</h3>';
                break;
            }
        }?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>
</html>