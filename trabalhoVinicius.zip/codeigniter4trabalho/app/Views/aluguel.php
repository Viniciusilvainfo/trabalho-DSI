<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videogame</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: purple;
        }
        
        form {
            color: white;
        }
        table {
            background-color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Videogames</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">Página Principal</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/fazerAluguel">Fazer aluguel</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarJogo">Adicionar jogo</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarUsuario">Adicionar usuário</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarCategoria">Adicionar categoria</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>

    <form action="/fazerAluguel" class="mt-5 w-50 mx-auto" method="post">
    <table class="table table-hover mt-5 w-100 mx-auto">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Nome</th>
        <th scope="col">Plataforma</th>
        <th scope="col">Quantidade</th>
        <th scope="col">Alugar jogo</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach($jogos as $chave => $dado) { ?>
        <tr>
            <th scope="row"><?=$dado['id']?></th> 
            <td><?=$dado['nome']?></td>
            <td><?=$dado['sistema']?></td>
            <td><?=$dado['quantidade']?></td>
            <td>
            <input type="checkbox" name="jogo<?=$dado['id']?>" value="<?=$dado['id']?>">
            </td>
        </tr>
        <?php } ?>
    </tbody>
    </table>
      <h3 class="text-center">Escolher usuário</h3>
      <div class="mb-3">
        <label for="nome" class="form-label">Nome:</label>
        <select name="usuario" class="form-select" aria-label="Default select example">
            <?php foreach($usuarios as $chave => $dado) { ?>
                <option value="<?=$dado['id']?>"><?=$dado['nome']?></option>
            <?php } ?>
        </select>
      </div>
    <button type="submit" class="btn btn-primary">Cadastrar</button>
  </form>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>