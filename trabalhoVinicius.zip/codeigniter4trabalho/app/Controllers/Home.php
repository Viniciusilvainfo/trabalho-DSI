<?php

namespace App\Controllers;

use App\Models\Jogos;
use App\Models\Usuarios;
use App\Models\JogosUsuario;
use App\Models\Categoria;

class Home extends BaseController {

    public function todosJogos() {
        $jogosModel = new Jogos();
        $todos_os_dados = $jogosModel->findAll();
        return $todos_os_dados;
    }

    public function todasCategorias() {
        $categoriaModel = new Categoria();
        $todos_os_dados = $categoriaModel->findAll();
        return $todos_os_dados;
    }

    public function todosConsoles() {
        $jogosModel = new Jogos();
        $todos_os_dados = $jogosModel->distinct('sistema')->groupby('sistema')->findAll();
        return $todos_os_dados;
    }
    
    public function todosUsuarios() {
        $usuariosModel = new Usuarios();
        $todosUsuarios = $usuariosModel->findAll();
        return $todosUsuarios;
    }

    public function pesquisa() {
        $dados = $this->request->getVar();
        $jogosModel = new Jogos();
        if($dados['campo'] == 1) {
            $jogo = $dados['jogo'];
            $todos_os_dados = $jogosModel->havingLike('nome', $jogo)->findAll();
            if(count($todos_os_dados) == 0) {
                return redirect()->to(base_url('/?erro=1'));
            }
        }else if($dados['campo'] == 2) {
            $console = $dados['console'];
            $todos_os_dados = $jogosModel->havingLike('sistema', $console)->findAll();
            if(count($todos_os_dados) == 0) {
                return redirect()->to(base_url('/?erro=1'));
            }
        }else if($dados['campo'] == 3) {
            $categoria = $dados['categoria'];
            $todos_os_dados = $jogosModel->havingLike('categoria', $categoria)->findAll();
            if(count($todos_os_dados) == 0) {
                return redirect()->to(base_url('/?erro=1'));
            }
        }else if($dados['campo'] == 4) {
            $maiorpreco = $jogosModel->selectmax('preco')->first()['preco'];
            $todos_os_dados = $jogosModel->where('preco', $maiorpreco)->first();
            $data['cont'] = 1;
            if(count($todos_os_dados) == 0) {
                return redirect()->to(base_url('/?erro=1'));
            }
        }else if($dados['campo'] == 5) {
            $maiorqtde = $jogosModel->selectmax('quantidade')->first()['quantidade'];
            $todos_os_dados = $jogosModel->where('quantidade', $maiorqtde)->first();
            $data['cont'] = 1;
            if(count($todos_os_dados) == 0) {
                return redirect()->to(base_url('/?erro=1'));
            }
        }

        $todas_categorias = $this->todasCategorias();
        $todos_consoles = $this->todosConsoles();
        $data['categorias'] = $todas_categorias;
        $data['consoles'] = $todos_consoles;
        $data['dados'] = $todos_os_dados;
            return view('index', $data);
    }

    public function relatorio() {
        $jogosModel = new Jogos();
        $alugueis = $jogosModel->select('jogos.nome as jogo, preco, usuarios.nome')->join('jogos_usuarios', 'jogos.id = jogos_usuarios.jogo')->join('usuarios', 'usuarios.id = jogos_usuarios.usuario')->orderby('usuarios.nome')->findAll();

        $pessoa = '';
        $gastos = array();
        foreach($alugueis as $chave => $aluguel) {

            if($aluguel['nome'] == $pessoa) {
                array_unshift($gastos[$pessoa], $aluguel['jogo']);
                $gastos[$pessoa]['valor'] = $gastos[$pessoa]['valor'] + $aluguel['preco']; 
            }else {
                $pessoa = $aluguel['nome'];
                $gastos[$pessoa] = array();
                $gastos[$pessoa]['valor'] = 0;
                array_unshift($gastos[$pessoa], $aluguel['jogo']);
                $gastos[$pessoa]['valor'] = $gastos[$pessoa]['valor'] + $aluguel['preco']; 
            }
        }
        $data['gastos'] = $gastos;
        return view('relatorio', $data);
    }

    public function index(){
        $todos_os_dados = $this->todosJogos();
        $todas_categorias = $this->todasCategorias();
        $todos_consoles = $this->todosConsoles();
        $data['dados'] = $todos_os_dados;
        $data['categorias'] = $todas_categorias;
        $data['consoles'] = $todos_consoles;
        return view('index', $data);
    }

    public function mostraAdicionarJogo() {
        $todas_categorias = $this->todasCategorias();
        $data['categorias'] = $todas_categorias;
        return view('formCadastroJogo', $data);
    }

    public function mostraAdicionarCategoria() {
        $data['tipo'] = 'categoria';
        return view('formCadastroUsuario', $data);
    }
    
    public function mostraAdicionarUsuario() {
        $data['tipo'] = 'usuario';
        return view('formCadastroUsuario', $data);
    }
    
    public function mostraEdicao() {
        $id = $this->request->getVar('jogo');
        $jogosModel = new Jogos();
        $jogo = $jogosModel->where('id',$id)->first();
        // var_dump($jogo);
        $categorias = $this->todasCategorias();
        $data['jogo'] = $jogo;
        $data['categorias'] = $categorias;
        return view('formEdit', $data);
    }

    public function editar() {
        $id =  $this->request->getVar('jogo'); 
        $data = array (
            'nome' =>  $this->request->getVar('nome'),
            'sistema' => $this->request->getVar('sistema'),
            'descricao' => $this->request->getVar('descricao'),
            'quantidade' => $this->request->getVar('quantidade'),
            'preco' => $this->request->getVar('preco'),
            'categoria' =>  $this->request->getVar('categoria')
        );
        $jogosModel = new Jogos();
        $jogosModel->set($data)->where('id', $id)->update();
        return redirect()->to(base_url('/'));
    }

    public function verificaQuantidade($id) { 
        $jogosModel = new Jogos();
        $jogo = $jogosModel->where('id',$id)->first();
        $quantidade = (int) $jogo['quantidade'];
        if($quantidade < 1) {
            echo 'Esse jogo não está mais disponível';
            echo '<a href="/fazerAluguel">Voltar</a>';
            return false;
        }
        return $quantidade;
    }

    public function descontaQuantidade($id, $quantidade) {
        $jogosModel = new Jogos();
        $jogo = $jogosModel->where('id',$id)->first();
        $jogosModel->set('quantidade', $quantidade)->where('id', $id)->update();
    }

    public function efetuarAluguel($jogo, $usuario) {
        $jogosUsuario = new JogosUsuario();
        $data = array (
            'jogo' => $jogo,
            'usuario' => $usuario
        );
        $jogosUsuario->insert($data);
    }

    public function fazerAluguel() {
        $dados = $this->request->getPost();

        if(count($dados) < 2) {
            echo 'Você deve escolher pelo menos um jogo';
            echo '<br> <a href="/fazerAluguel">Voltar</a>';
            return false;
        }
        foreach($dados as $chave => $dado) {
            $pos = strpos($chave, 'jogo');
            if(is_numeric(strpos($chave, 'jogo'))) {
                $quantidade = $this->verificaQuantidade($dado) - 1;
                if (!$quantidade) {
                    return redirect()->to(base_url('/'));
                    break;
                }

                $this->descontaQuantidade($dado, $quantidade);
                $this->efetuarAluguel($dado, $dados['usuario']);
            }
        }
        return redirect()->to(base_url('/'));
    }

    public function remover() {
        $jogosUsuario = new JogosUsuario();
        $jogosModel = new Jogos();
        $id = $this->request->getVar('jogo');
        $jogosUsuario->delete(['jogo' => $id]);
        $jogosModel->delete(['id' => $id]);
        return redirect()->to(base_url('/'));
    }

    public function adicionarUsuario() {
        $usuariosModel = new Usuarios();
        $nome = $this->request->getVar('nome');
        $data['nome'] = $nome;
        $usuariosModel->insert($data);
        return redirect()->to(base_url('/'));
    }

    public function adicionarCategoria() {
        $categoriaModel = new Categoria();
        $nome = $this->request->getVar('nome');
        $data['nome'] = $nome;
        $categoriaModel->insert($data);
        return redirect()->to(base_url('/'));
    }

    public function mostraPaginaAluguel() {
        $todos_os_dados = $this->todosJogos();
        $todosUsuarios = $this->todosUsuarios();
        $data['jogos'] = $todos_os_dados;
        $data['usuarios'] = $todosUsuarios;
        return view('aluguel', $data);
    }

    public function adicionarJogo() {
        $jogosModel = new Jogos();
        $nome = $this->request->getVar('nome');
        $sistema = $this->request->getVar('sistema');
        $descricao = $this->request->getVar('descricao');
        $quantidade = $this->request->getVar('quantidade');
        $preco = $this->request->getVar('preco');
        $categoria = $this->request->getVar('categoria');

        $data['nome'] = $nome;
        $data['sistema'] = $sistema;
        $data['descricao'] = $descricao;
        $data['quantidade'] = $quantidade;
        $data['preco'] = $preco;
        $data['categoria'] = $categoria;
        $jogosModel->insert($data);

        return redirect()->to(base_url('/'));
    }
}
