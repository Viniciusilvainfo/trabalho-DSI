<?php

namespace App\Models;

use CodeIgniter\Model;

class JogosUsuario extends Model
{
    protected $table            = 'jogos_usuarios';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['jogo', 'usuario'];
}
