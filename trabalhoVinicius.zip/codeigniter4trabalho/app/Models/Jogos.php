<?php

namespace App\Models;

use CodeIgniter\Model;

class Jogos extends Model
{
    protected $table            = 'jogos';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['nome', 'sistema', 'categoria', 'descricao', 'preco', 'quantidade'];

}


// php spark make:model JogosUsuario