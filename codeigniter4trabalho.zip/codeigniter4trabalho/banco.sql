CREATE DATABASE loja;

drop table jogos_usuarios;
drop table jogos;
drop table categorias;
drop table usuarios;

create table categorias (
	id int AUTO_INCREMENT not null,
    nome varchar(100) not null,
    PRIMARY key(id)
);

create table jogos(
	id int AUTO_INCREMENT not null,
    nome varchar(100) not null,
    sistema varchar(50) not null,
    descricao varchar(200) not null,
    categoria int not null,
    preco decimal(5,2) not null,
    quantidade int not null,
    FOREIGN key (categoria) references categorias(id),
    PRIMARY key(id)
);

create table usuarios (
	id int AUTO_INCREMENT not null,
    nome varchar(100) not null,
    tipo varchar(10) not null default 'usuario',
    PRIMARY key(id)
);

create table jogos_usuarios (
	jogo int not null,
    usuario int not null,
    foreign key(jogo) references jogos(id),
    foreign key(usuario) references usuarios(id),
    primary key(jogo, usuario)
);


insert into categorias(nome) values 
('RPG'),
('esporte'),
('acao'),
('mundo aberto'),
('tiro'),
('terror');

insert into jogos(nome, sistema, descricao, categoria, preco, quantidade) values 
('Fifa', 'XBOX Series X', 'jogo de futebol', 2, 255.50, 20),
('Elden Ring', 'PS5', 'jogo de rpg', 1, 195.46, 30),
('GTA V', 'PC', 'Jogo de tiro e mundo aberto para jogar online com os amigos', 4, 155.50, 40);