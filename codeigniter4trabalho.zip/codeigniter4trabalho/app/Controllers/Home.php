<?php

namespace App\Controllers;

use App\Models\Jogos;
use App\Models\Usuarios;

// $db = \Config\Database::connect();

class Home extends BaseController {

    public function todosJogos() {
        $jogosModel = new Jogos();
        $todos_os_dados = $jogosModel->findAll();
        return $todos_os_dados;
    }
    
    public function todosUsuarios() {
        $usuariosModel = new Usuarios();
        $todosUsuarios = $usuariosModel->findAll();
        return $todosUsuarios;
    }

    public function index(){
        $todos_os_dados = $this->todosJogos();
        $data['dados'] = $todos_os_dados;
        return view('index', $data);
    }

    public function mostraAdicionarJogo() {
        return view('formCadastroJogo');
    }

    public function mostraAdicionarUsuario() {
        return view('formCadastroUsuario');
    }

    public function verificaQuantidade($id) { 
        $jogosModel = new Jogos();
        // echo 'Esse é o id do jogo '.$id.'<br><br><br>';
        $limit = 1;
        $offset = 0;
        // $jogo = $jogosModel->getWhere(['id' => $id], $limit, $offset);
        $jogo = $jogosModel->where('id',$id)->first();
        $quantidade = (int) $jogo['quantidade'];
        if($quantidade < 1) {
            // mostra mensagem de erro
            return false;
        }else {
            return $quantidade;
        }
    }

    public function fazerAluguel() {
        /* 
            pegar os jogos que vão ser alugados
            pegar o usuário que vai alugar 
            ver se a quantidade disponível é maior que 0
            se a qtde for, descontar 1
        */
        $dados = $this->request->getPost();
        foreach($dados as $chave => $dado) {
            $a = 'jogo';
            $pos = strpos($chave, $a);
            if(is_numeric(strpos($chave, $a))) {
                $quantidade = $this->verificaQuantidade($dado);
                // APOS VER SE A QUANTIDADADE FOI > 1 DESCONTA 1 E ADICIONAR EM JOGO USUARIO
                if (!$quantidade) {
                    return redirect()->to(base_url('/'));
                    break;
                }
            }
        }
    }

    public function adicionarUsuario() {
        // return view('formCadastroUsuario');
        $usuariosModel = new Usuarios();
        $nome = $this->request->getVar('nome');
        $data['nome'] = $nome;
        $usuariosModel->insert($data);
        return redirect()->to(base_url('/'));
    }

    public function mostraPaginaAluguel() {
        $todos_os_dados = $this->todosJogos();
        $todosUsuarios = $this->todosUsuarios();
        $data['jogos'] = $todos_os_dados;
        $data['usuarios'] = $todosUsuarios;
        return view('aluguel', $data);
    }

    public function adicionarJogo() {
        $jogosModel = new Jogos();
        //$something = isset($_POST['nome']) ? $_POST['nome'] : null;
        $nome = $this->request->getVar('nome');
        $sistema = $this->request->getVar('sistema');
        $descricao = $this->request->getVar('descricao');
        $quantidade = $this->request->getVar('quantidade');
        $preco = $this->request->getVar('preco');
        $categoria = $this->request->getVar('categoria');

        $data['nome'] = $nome;
        $data['sistema'] = $sistema;
        $data['descricao'] = $descricao;
        $data['quantidade'] = $quantidade;
        $data['preco'] = $preco;
        $data['categoria'] = $categoria;

        // countAll() count quantidade de uma table
        // get(10, 20); limit de 10 a 20
        // getWhere(['id' => $id], $limit, $offset);
        // join('comments', 'comments.id = blogs.id');
        $jogosModel->insert($data);

        return redirect()->to(base_url('/'));
    }
}
