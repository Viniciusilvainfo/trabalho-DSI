<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Videogame</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: purple;
        }
        
        form {
            color: white;
        }
        table {
            background-color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Videogames</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="/">Página Principal</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/fazerAluguel">Fazer aluguel</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarJogo">Adicionar jogo</a>
                </li>
                <li class="nav-item">
                <a class="nav-link" href="/adicionarUsuario">Adicionar usuário</a>
                </li>
            </ul>
            </div>
        </div>
    </nav>
    <?php
    ?>
    <table class="table table-hover mt-5 w-75 mx-auto">
    <thead>
        <tr>
        <th scope="col">#</th>
        <th scope="col">Nome</th>
        <th scope="col">Descrição</th>
        <th scope="col">Plataforma</th>
        <th scope="col">Quantidade</th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach($dados as $chave => $dado) { ?>
        <tr>
            <th scope="row"><?=$dado['id']?></th> 
            <td><?=$dado['nome']?></td>
            <td><?=$dado['descricao']?></td>
            <td><?=$dado['sistema']?></td>
            <td><?=$dado['quantidade']?></td>
        </tr>
        <?php } ?>
    </tbody>
    </table>
</body>
</html>