<?php

namespace App\Models;

use CodeIgniter\Model;

class Itens extends Model
{
    protected $table            = 'jogos';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $allowedFields    = ['nome', 'sistema', 'descricao', 'preco', 'qtde'];
}


// php spark make:model Itens